export interface WordEntry {
  word: string;
  english: string;
  synonyms: string[];
}

export interface Category {
  id: string;
  title: string;
  odia: string;
  emoji: string;
  words: WordEntry[];
}

export const categories: Category[] = [
  {
    id: "nature",
    title: "Nature & Environment",
    odia: "ପ୍ରକୃତି ଓ ପରିବେଶ",
    emoji: "🌿",
    words: [
      { word: "ଆକାଶ", english: "Sky", synonyms: ["ଗଗନ", "ନଭ", "ଅମ୍ବର", "ବ୍ୟୋମ", "ଅନ୍ତରୀକ୍ଷ"] },
      { word: "ସୂର୍ଯ୍ୟ", english: "Sun", synonyms: ["ରବି", "ଦିବାକର", "ଭାସ୍କର", "ମାର୍ତ୍ତଣ୍ଡ", "ଆଦିତ୍ୟ", "ପ୍ରଭାକର"] },
      { word: "ଚନ୍ଦ୍ର", english: "Moon", synonyms: ["ଜହ୍ନ", "ଶଶୀ", "ସୁଧାକର", "ମୃଗାଙ୍କ", "ନିଶାକର", "ଚାନ୍ଦ"] },
      { word: "ପୃଥିବୀ", english: "Earth", synonyms: ["ଧରିତ୍ରୀ", "ବସୁଧା", "ଧରା", "ଅବନୀ", "ମେଦିନୀ", "ବିଶ୍ୱମ୍ଭରା"] },
      { word: "ନଦୀ", english: "River", synonyms: ["ତଟିନୀ", "ସରିତ", "ନିମ୍ନଗା", "ସ୍ରୋତସ୍ୱିନୀ"] },
      { word: "ସମୁଦ୍ର", english: "Ocean", synonyms: ["ସାଗର", "ରତ୍ନାକର", "ଜଳଧି", "ପାରାବାର", "ବାରିଧି"] },
      { word: "ପର୍ବତ", english: "Mountain", synonyms: ["ଶୈଳ", "ଗିରି", "ଅଚଳ", "ନଗ", "ଭୂଧର"] },
      { word: "ପବନ", english: "Wind", synonyms: ["ବାୟୁ", "ସମୀର", "ମାରୁତ", "ଅନିଳ", "ପ୍ରଭଞ୍ଜନ"] },
      { word: "ଜଳ", english: "Water", synonyms: ["ପାଣି", "ନୀର", "ବାରି", "ତୋୟ", "ଅମ୍ବୁ", "ଉଦକ"] },
      { word: "ଅଗ୍ନି", english: "Fire", synonyms: ["ନିଆଁ", "ପାବକ", "ଅନଳ", "ବହ୍ନି", "ହୁତାଶନ"] },
      { word: "ବୃକ୍ଷ", english: "Tree", synonyms: ["ଗଛ", "ତରୁ", "ପାଦପ", "ଦ୍ରୁମ", "ବିଟପୀ"] },
      { word: "ପୁଷ୍ପ", english: "Flower", synonyms: ["ଫୁଲ", "କୁସୁମ", "ସୁମନ", "ପ୍ରସୂନ"] },
      { word: "ପତ୍ର", english: "Leaf", synonyms: ["ପତ୍ରକ", "ପଲ୍ଲବ", "କିଶଳୟ"] },
      { word: "ମେଘ", english: "Cloud", synonyms: ["ଜଳଦ", "ବାରିଦ", "ନୀରଦ", "ଜୀମୂତ", "ଘନ"] },
      { word: "ବର୍ଷା", english: "Rain", synonyms: ["ବୃଷ୍ଟି", "ପାବସ", "ବାରିପାତ"] },
      { word: "ରାତ୍ରି", english: "Night", synonyms: ["ନିଶା", "ରଜନୀ", "ଯାମିନୀ", "ଶର୍ବରୀ", "ବିଭାବରୀ"] },
      { word: "ଦିନ", english: "Day", synonyms: ["ଦିବସ", "ଅହ", "ବାର"] },
    ],
  },
  {
    id: "body",
    title: "Humans & Body",
    odia: "ମନୁଷ୍ୟ ଓ ଶରୀର",
    emoji: "🧠",
    words: [
      { word: "ମଣିଷ", english: "Human", synonyms: ["ମାନବ", "ନର", "ମନୁଜ"] },
      { word: "ଶରୀର", english: "Body", synonyms: ["ଦେହ", "କାୟା", "କଳେବର", "ଗାତ୍ର", "ତନୁ"] },
      { word: "ଆଖି", english: "Eye", synonyms: ["ନୟନ", "ଚକ୍ଷୁ", "ନେତ୍ର", "ଲୋଚନ", "ଅକ୍ଷି"] },
      { word: "କାନ", english: "Ear", synonyms: ["କର୍ଣ୍ଣ", "ଶ୍ରବଣ"] },
      { word: "ମୁଣ୍ଡ", english: "Head", synonyms: ["ମସ୍ତକ", "ଶିର"] },
      { word: "ହାତ", english: "Hand", synonyms: ["କର", "ହସ୍ତ", "ବାହୁ", "ଭୁଜ"] },
      { word: "ଗୋଡ଼", english: "Leg", synonyms: ["ପାଦ", "ଚରଣ"] },
      { word: "ରକ୍ତ", english: "Blood", synonyms: ["ରୁଧିର", "ଶୋଣିତ"] },
      { word: "ପାଟି", english: "Mouth", synonyms: ["ମୁଖ", "ବଦନ", "ଆସ୍ୟ"] },
      { word: "ଦାନ୍ତ", english: "Tooth", synonyms: ["ଦନ୍ତ", "ରଦନ"] },
      { word: "ଚୁଟି", english: "Hair", synonyms: ["କେଶ", "ଅଳକ", "କୁନ୍ତଳ"] },
      { word: "ମନ", english: "Mind", synonyms: ["ଚିତ୍ତ", "ହୃଦୟ", "ଅନ୍ତଃକରଣ"] },
    ],
  },
  {
    id: "relations",
    title: "Relationships",
    odia: "ସମ୍ପର୍କ",
    emoji: "👨‍👩‍👧",
    words: [
      { word: "ପିତା", english: "Father", synonyms: ["ବାପା", "ଜନକ", "ତାତ"] },
      { word: "ମାତା", english: "Mother", synonyms: ["ମା", "ଜନନୀ", "ଅମ୍ବା", "ପ୍ରସୂତି"] },
      { word: "ପୁତ୍ର", english: "Son", synonyms: ["ପୁଅ", "ସୁତ", "ତନୟ", "ନନ୍ଦନ", "ଆତ୍ମଜ"] },
      { word: "କନ୍ୟା", english: "Daughter", synonyms: ["ଝିଅ", "ସୁତା", "ତନୟା", "ନନ୍ଦିନୀ", "ଦୁହିତା"] },
      { word: "ଭ୍ରାତା", english: "Brother", synonyms: ["ଭାଇ", "ସହୋଦର"] },
      { word: "ଭଗିନୀ", english: "Sister", synonyms: ["ଭଉଣୀ", "ସହୋଦରା"] },
      { word: "ପତି", english: "Husband", synonyms: ["ସ୍ୱାମୀ", "ନାଥ", "ଭର୍ତ୍ତା", "କାନ୍ତ", "ପ୍ରାଣେଶ୍ୱର"] },
      { word: "ପତ୍ନୀ", english: "Wife", synonyms: ["ଭାର୍ଯ୍ୟା", "ଦାରା", "ଅର୍ଦ୍ଧାଙ୍ଗିନୀ", "ଗୃହିଣୀ", "କାନ୍ତା"] },
      { word: "ବନ୍ଧୁ", english: "Friend", synonyms: ["ସଖା", "ମିତ୍ର", "ସୁହୃଦ", "ସାଥୀ"] },
    ],
  },
  {
    id: "animals",
    title: "Animals & Birds",
    odia: "ପଶୁପକ୍ଷୀ",
    emoji: "🦁",
    words: [
      { word: "ସିଂହ", english: "Lion", synonyms: ["କେଶରୀ", "ପଶୁରାଜ", "ମୃଗେନ୍ଦ୍ର"] },
      { word: "ହାତୀ", english: "Elephant", synonyms: ["ଗଜ", "ହସ୍ତୀ", "କୁଞ୍ଜର", "ମାତଙ୍ଗ", "ଦ୍ୱିରଦ"] },
      { word: "ଘୋଡ଼ା", english: "Horse", synonyms: ["ଅଶ୍ୱ", "ଘୋଟକ", "ତୁରଗ", "ବାଜୀ"] },
      { word: "ସର୍ପ", english: "Snake", synonyms: ["ସାପ", "ଅହି", "ଭୁଜଙ୍ଗ", "ବିଷଧର", "ନାଗ"] },
      { word: "ପକ୍ଷୀ", english: "Bird", synonyms: ["ବିହଗ", "ଖଗ", "ବିହଙ୍ଗମ", "ପକ୍ଷୀରାଜ"] },
      { word: "କୋଇଲି", english: "Cuckoo", synonyms: ["କୋକିଳ", "ପରଭୃତ", "ପିକ"] },
      { word: "ଭ୍ରମର", english: "Bee", synonyms: ["ମହୁମାଛି", "ଅଳି", "ଷଟପଦ", "ମଧୁକର"] },
      { word: "ମୟୂର", english: "Peacock", synonyms: ["ଶିଖୀ", "କଳାପୀ", "କେକୀ"] },
    ],
  },
  {
    id: "other",
    title: "Important Words",
    odia: "ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ ଶବ୍ଦ",
    emoji: "📚",
    words: [
      { word: "ଗୃହ", english: "House", synonyms: ["ଘର", "ସଦନ", "ନିକେତନ", "ଆଳୟ", "ନିବାସ"] },
      { word: "ରାଜା", english: "King", synonyms: ["ନୃପତି", "ଭୂପାଳ", "ନରେଶ", "ମହାରାଜ"] },
      { word: "ଶତ୍ରୁ", english: "Enemy", synonyms: ["ଅରି", "ରିପୁ", "ବୈରୀ", "ବିପକ୍ଷ"] },
      { word: "ଯୁଦ୍ଧ", english: "War", synonyms: ["ରଣ", "ସମର", "ସଂଗ୍ରାମ", "ବିଗ୍ରହ"] },
      { word: "ସୁନ୍ଦର", english: "Beautiful", synonyms: ["ମନୋହର", "ରମଣୀୟ", "ଚାରୁ", "ଶୋଭନ"] },
      { word: "ଇଚ୍ଛା", english: "Desire", synonyms: ["ଅଭିଳାଷ", "କାମନା", "ବାଞ୍ଛା", "ଆକାଂକ୍ଷା"] },
      { word: "ଧନ", english: "Wealth", synonyms: ["ସମ୍ପତ୍ତି", "ବିଭବ", "ଅର୍ଥ", "ବସୁ"] },
      { word: "ସୁନା", english: "Gold", synonyms: ["ସ୍ୱର୍ଣ୍ଣ", "କନକ", "ହେମ", "କାଞ୍ଚନ"] },
      { word: "ବିଦ୍ୟା", english: "Knowledge", synonyms: ["ଜ୍ଞାନ", "ଶିକ୍ଷା"] },
      { word: "ପଣ୍ଡିତ", english: "Scholar", synonyms: ["ବିଦ୍ୱାନ", "ଜ୍ଞାନୀ", "ସୁଧୀ", "କୋବିଦ"] },
      { word: "ମୂର୍ଖ", english: "Fool", synonyms: ["ଅଜ୍ଞ", "ବୋକା", "ମୁଢ଼"] },
      { word: "ସତ୍ୟ", english: "Truth", synonyms: ["ସତ", "ଋତ"] },
      { word: "ଆଲୋକ", english: "Light", synonyms: ["ଦୀପ୍ତି", "ପ୍ରଭା", "ଜ୍ୟୋତି", "କିରଣ"] },
      { word: "ଅନ୍ଧାର", english: "Darkness", synonyms: ["ତିମିର", "ତମସା", "ଅନ୍ଧକାର"] },
      { word: "ଅମୃତ", english: "Nectar", synonyms: ["ସୁଧା", "ପିୟୂଷ", "ଅମିୟ"] },
      { word: "ପବିତ୍ର", english: "Pure", synonyms: ["ପାବନ", "ପୁଣ୍ୟ", "ଶୁଦ୍ଧ", "ନିର୍ମଳ"] },
    ],
  },
  {
    id: "adjectives",
    title: "Adjectives",
    odia: "ବିଶେଷଣ ଶବ୍ଦ",
    emoji: "✨",
    words: [
      { word: "ବଡ଼", english: "Big", synonyms: ["ବିଶାଳ", "ମହାନ", "ବୃହତ"] },
      { word: "ଛୋଟ", english: "Small", synonyms: ["କ୍ଷୁଦ୍ର", "କଣିକା"] },
      { word: "ଧଳା", english: "White", synonyms: ["ଶୁଭ୍ର", "ସ୍ୱେତ", "ଧବଳ"] },
      { word: "କଳା", english: "Black", synonyms: ["କୃଷ୍ଣ", "ଶ୍ୟାମଳ"] },
      { word: "ନୂଆ", english: "New", synonyms: ["ନୂତନ", "ନବ"] },
      { word: "ପୁରୁଣା", english: "Old", synonyms: ["ପ୍ରାଚୀନ", "ପୁରାତନ"] },
    ],
  },
  {
    id: "gods",
    title: "God & Religion",
    odia: "ଭଗବାନ ଓ ଧର୍ମ",
    emoji: "🙏",
    words: [
      { word: "ଈଶ୍ୱର", english: "God", synonyms: ["ଭଗବାନ", "ପରମାତ୍ମା", "ଜଗନ୍ନାଥ", "ବିଭୁ", "ପ୍ରଭୁ"] },
      { word: "ଲକ୍ଷ୍ମୀ", english: "Lakshmi", synonyms: ["କମଳା", "ପଦ୍ମା", "ଶ୍ରୀ", "ହରିପ୍ରିୟା"] },
      { word: "ସରସ୍ୱତୀ", english: "Saraswati", synonyms: ["ବାଣୀ", "ବାଗ୍ଦେବୀ", "ଶାରଦା", "ବୀଣାପାଣି"] },
      { word: "ଶିବ", english: "Shiva", synonyms: ["ମହାଦେବ", "ଶମ୍ଭୁ", "ଶଙ୍କର", "ପଶୁପତି", "ତ୍ରିଲୋଚନ"] },
      { word: "ଗଣେଶ", english: "Ganesh", synonyms: ["ବିଘ୍ନେଶ୍ୱର", "ଗଜାନନ", "ବିନାୟକ", "ଲମ୍ବୋଦର"] },
    ],
  },
];

export const allWords: WordEntry[] = categories.flatMap((cat) => cat.words);

export function searchWords(query: string): { word: WordEntry; category: Category }[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const results: { word: WordEntry; category: Category }[] = [];

  for (const cat of categories) {
    for (const word of cat.words) {
      const matchesWord = word.word.includes(query.trim()) || word.english.toLowerCase().includes(q);
      const matchesSynonym = word.synonyms.some((s) => s.includes(query.trim()));
      if (matchesWord || matchesSynonym) {
        results.push({ word, category: cat });
      }
    }
  }

  return results;
}
