import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  FlatList,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CategoryCard } from "@/components/CategoryCard";
import { SearchBar } from "@/components/SearchBar";
import { WordCard } from "@/components/WordCard";
import { useColors } from "@/hooks/useColors";
import { categories, searchWords } from "@/data/words";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [query, setQuery] = useState("");

  const searchResults = query.trim().length > 0 ? searchWords(query) : [];
  const isSearching = query.trim().length > 0;

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 34 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { backgroundColor: colors.primary, paddingTop: topPadding + 16 },
        ]}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={[styles.headerTitle, { color: colors.primaryForeground }]}>
              ଓଡ଼ିଆ ଶବ୍ଦ ଭଣ୍ଡାର
            </Text>
            <Text style={[styles.headerSubtitle, { color: "rgba(255,255,255,0.8)" }]}>
              Odia Word Finder & Synonyms
            </Text>
          </View>
          <TouchableOpacity
            style={[styles.statsBtn, { backgroundColor: "rgba(255,255,255,0.18)" }]}
            onPress={() => router.push("/browse")}
            activeOpacity={0.7}
          >
            <Feather name="grid" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={styles.searchWrapper}>
          <SearchBar value={query} onChangeText={setQuery} />
        </View>
      </View>

      {isSearching ? (
        <FlatList
          data={searchResults}
          keyExtractor={(item, idx) => `${item.word.word}-${idx}`}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: bottomPadding + 20 },
          ]}
          ListHeaderComponent={
            <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>
              {searchResults.length} result{searchResults.length !== 1 ? "s" : ""} for "{query}"
            </Text>
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Feather name="search" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No words found for "{query}"
              </Text>
              <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>
                Try searching in Odia or English
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <WordCard
              word={item.word}
              categoryEmoji={item.category.emoji}
            />
          )}
          scrollEnabled={!!searchResults.length}
        />
      ) : (
        <ScrollView
          contentContainerStyle={[styles.scrollContent, { paddingBottom: bottomPadding + 20 }]}
          showsVerticalScrollIndicator={false}
        >
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>
            Browse by Category
          </Text>
          {categories.map((cat) => (
            <CategoryCard
              key={cat.id}
              category={cat}
              onPress={() => router.push({ pathname: "/category/[id]", params: { id: cat.id } })}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    shadowColor: "#6C3EFF",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
    zIndex: 10,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
  },
  headerSubtitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  statsBtn: {
    width: 42,
    height: 42,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  searchWrapper: {
    marginTop: 0,
  },
  scrollContent: {
    padding: 20,
  },
  listContent: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: "center",
    paddingTop: 60,
    gap: 10,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
    marginTop: 8,
  },
  emptyHint: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
});
