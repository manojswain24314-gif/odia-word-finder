import React, { useState } from "react";
import {
  FlatList,
  Platform,
  SectionList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WordCard } from "@/components/WordCard";
import { useColors } from "@/hooks/useColors";
import { allWords, categories, Category } from "@/data/words";

export default function BrowseScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [selectedCat, setSelectedCat] = useState<string | null>(null);

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom;

  const filteredWords = selectedCat
    ? categories.find((c) => c.id === selectedCat)?.words ?? []
    : allWords;

  const selectedCategory = selectedCat
    ? categories.find((c) => c.id === selectedCat)
    : null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { backgroundColor: colors.primary, paddingTop: topPadding + 16 },
        ]}
      >
        <Text style={[styles.title, { color: colors.primaryForeground }]}>All Words</Text>
        <Text style={[styles.subtitle, { color: "rgba(255,255,255,0.75)" }]}>
          {filteredWords.length} entries
        </Text>
        <FlatList
          horizontal
          data={[{ id: null, title: "All", odia: "", emoji: "📖" } as any, ...categories]}
          keyExtractor={(item) => item.id ?? "all"}
          showsHorizontalScrollIndicator={false}
          style={styles.filterRow}
          renderItem={({ item }) => {
            const isActive = selectedCat === item.id;
            return (
              <TouchableOpacity
                style={[
                  styles.filterChip,
                  {
                    backgroundColor: isActive ? "#fff" : "rgba(255,255,255,0.18)",
                  },
                ]}
                onPress={() => setSelectedCat(item.id)}
                activeOpacity={0.7}
              >
                <Text style={styles.filterEmoji}>{item.emoji}</Text>
                <Text
                  style={[
                    styles.filterLabel,
                    { color: isActive ? colors.primary : "#fff" },
                  ]}
                >
                  {item.id === null ? "All" : item.title}
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      <FlatList
        data={filteredWords}
        keyExtractor={(item) => item.word}
        contentContainerStyle={[styles.list, { paddingBottom: bottomPadding + 20 }]}
        renderItem={({ item }) => {
          const cat = categories.find((c) => c.words.some((w) => w.word === item.word));
          return <WordCard word={item} categoryEmoji={cat?.emoji} />;
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No words found
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    shadowColor: "#6C3EFF",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  title: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    marginBottom: 2,
  },
  subtitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginBottom: 14,
  },
  filterRow: {
    marginHorizontal: -2,
  },
  filterChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
    marginRight: 8,
    gap: 5,
  },
  filterEmoji: {
    fontSize: 14,
  },
  filterLabel: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  list: {
    padding: 20,
  },
  empty: {
    alignItems: "center",
    paddingTop: 60,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: "Inter_400Regular",
  },
});
