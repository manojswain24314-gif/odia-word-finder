import { Feather } from "@expo/vector-icons";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import React from "react";
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WordCard } from "@/components/WordCard";
import { useColors } from "@/hooks/useColors";
import { categories } from "@/data/words";

export default function CategoryScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const category = categories.find((c) => c.id === id);

  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom;

  if (!category) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground, padding: 20 }}>Category not found</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ headerShown: false }} />

      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.primary,
            paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity
            style={[styles.backBtn, { backgroundColor: "rgba(255,255,255,0.2)" }]}
            onPress={() => router.back()}
          >
            <Feather name="arrow-left" size={20} color="#fff" />
          </TouchableOpacity>
          <View style={[styles.emojiContainer, { backgroundColor: "rgba(255,255,255,0.18)" }]}>
            <Text style={styles.emoji}>{category.emoji}</Text>
          </View>
        </View>
        <Text style={[styles.title, { color: colors.primaryForeground }]}>{category.title}</Text>
        <Text style={[styles.odia, { color: "rgba(255,255,255,0.8)" }]}>{category.odia}</Text>
        <Text style={[styles.count, { color: "rgba(255,255,255,0.65)" }]}>
          {category.words.length} words
        </Text>
      </View>

      <FlatList
        data={category.words}
        keyExtractor={(item) => item.word}
        contentContainerStyle={[styles.list, { paddingBottom: bottomPadding + 20 }]}
        renderItem={({ item }) => <WordCard word={item} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    shadowColor: "#6C3EFF",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  emojiContainer: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: {
    fontSize: 26,
  },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginBottom: 3,
  },
  odia: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    marginBottom: 4,
  },
  count: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  list: {
    padding: 20,
  },
});
