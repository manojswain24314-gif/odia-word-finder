const colors = {
  light: {
    text: "#1a1033",
    tint: "#6C3EFF",

    background: "#F5F3FF",
    foreground: "#1a1033",

    card: "#FFFFFF",
    cardForeground: "#1a1033",

    primary: "#6C3EFF",
    primaryForeground: "#FFFFFF",

    secondary: "#EDE9FE",
    secondaryForeground: "#4c2fcc",

    muted: "#EDE9FE",
    mutedForeground: "#7c6f9a",

    accent: "#F5B800",
    accentForeground: "#1a1033",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#DDD6FE",
    input: "#DDD6FE",

    surface: "#FFFFFF",
    surfaceAlt: "#EDE9FE",

    synonymBadge: "#6C3EFF",
    synonymBadgeFg: "#FFFFFF",

    categoryCard: "#FFFFFF",
    headerBg: "#6C3EFF",
    headerFg: "#FFFFFF",
  },
  radius: 14,
};

export default colors;
