import React, { useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View, ScrollView } from "react-native";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { WordEntry } from "@/data/words";

interface Props {
  word: WordEntry;
  categoryEmoji?: string;
  onPress?: () => void;
  compact?: boolean;
}

export function WordCard({ word, categoryEmoji, onPress, compact = false }: Props) {
  const colors = useColors();
  const [expanded, setExpanded] = useState(false);

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (onPress) {
      onPress();
    } else {
      setExpanded((prev) => !prev);
    }
  };

  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
      onPress={handlePress}
      activeOpacity={0.75}
    >
      <View style={styles.header}>
        <View style={styles.wordSection}>
          {categoryEmoji && (
            <Text style={styles.catEmoji}>{categoryEmoji}</Text>
          )}
          <View>
            <Text style={[styles.word, { color: colors.foreground }]}>{word.word}</Text>
            <Text style={[styles.english, { color: colors.mutedForeground }]}>{word.english}</Text>
          </View>
        </View>
        <View style={[styles.countBadge, { backgroundColor: colors.secondary }]}>
          <Text style={[styles.countText, { color: colors.primary }]}>
            {word.synonyms.length} syn
          </Text>
        </View>
      </View>

      {(!compact || expanded || !onPress) && (
        <View style={styles.synonymsContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.synonymsRow}>
            {word.synonyms.map((syn, idx) => (
              <View key={idx} style={[styles.synBadge, { backgroundColor: colors.secondary }]}>
                <Text style={[styles.synText, { color: colors.primary }]}>{syn}</Text>
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      {compact && onPress && !expanded && (
        <Text style={[styles.tapHint, { color: colors.mutedForeground }]}>Tap to expand</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    shadowColor: "#6C3EFF",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  wordSection: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  catEmoji: {
    fontSize: 20,
    marginRight: 10,
  },
  word: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  english: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 1,
  },
  countBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    marginLeft: 8,
  },
  countText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  synonymsContainer: {
    marginTop: 4,
  },
  synonymsRow: {
    flexDirection: "row",
  },
  synBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
  },
  synText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  tapHint: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    marginTop: 4,
  },
});
